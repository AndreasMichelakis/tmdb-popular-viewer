import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './pages/home/home.component';
import { MovieViewerComponent } from './components/movie-viewer/movie-viewer.component';
import { MovieListComponent } from './components/movie-list/movie-list.component';


@NgModule({
  declarations: [HomeComponent, MovieListComponent, MovieViewerComponent],
  imports: [
    CommonModule
  ]
})
export class HomeModule { }
