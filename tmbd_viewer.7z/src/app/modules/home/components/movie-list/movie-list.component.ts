import { Component, OnInit, HostListener } from '@angular/core';
import { MovieService } from 'src/app/core/services/movie.service';
import { Movie } from 'src/app/shared/models/movie';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.scss']
})
export class MovieListComponent implements OnInit {

  public movies: Movie[] = [];
  private didLoadOnce = false;

  constructor(public movieService: MovieService) {
    movieService.getMovieArray().subscribe((movieArray) => {
      this.movies = this.movies.concat(movieArray);
    });
  }

  ngOnInit(): void {

  }

  public viewMovie(movie: Movie): void {
    this.movieService.setCurrentMovieView(movie);
  }

  @HostListener('scroll', ['$event'])
  public onScroll(event: any): void {
    // User has scrolled to the end of the list
    //  visible height + pixel scrolled >= total height
    if (event.target.offsetHeight + event.target.scrollTop >= event.target.scrollHeight) {
      if (!this.didLoadOnce) { // Load next two pages from server
        this.didLoadOnce = true;
        this.movieService.fetchNextTwoPages().then(() => this.didLoadOnce = false);
      }
    }
  }


}
