export enum SortMethod {
    Most_Popular = 'popularity.asc',
    Least_Popular = 'popularity.desc'
}
