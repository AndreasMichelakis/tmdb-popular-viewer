export interface UnsuccesfulResponse {
  status_code: number;
  status_message: string;
}
